# EV Battery Early Warning System

A FastAPI service that deploys the neural-network model from the EV Battery Failure assignment. It estimates battery failure probability from 15 battery health, charging, electrical, thermal, and usage features.

## Model results

- Accuracy: 91.80%
- Precision: 55.11%
- Recall: 95.06%
- F1 Score: 69.77%
- ROC-AUC: 98.10%

## Project structure

```text
EV-Battery-Early-Warning-System/
├── app/
│   ├── main.py
│   └── static/
│       └── index.html
├── artifacts/
│   ├── battery_failure_model.joblib
│   ├── battery_imputer.joblib
│   ├── battery_scaler.joblib
│   └── model_info.json
├── Dockerfile
├── requirements.txt
├── .dockerignore
├── .gitignore
└── README.md
```

## Run locally

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

macOS/Linux:
```bash
source venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Start the API:

```bash
uvicorn app.main:app --reload
```

Open:

- `http://127.0.0.1:8000` for the dashboard
- `http://127.0.0.1:8000/docs` for FastAPI documentation

## Docker

Build:

```bash
docker build -t ev-battery-warning .
```

Run:

```bash
docker run -p 8000:8000 -e PORT=8000 ev-battery-warning
```

## Deployment

The project is designed for deployment from GitHub to Railway. Railway detects the Dockerfile and builds the application from it.

