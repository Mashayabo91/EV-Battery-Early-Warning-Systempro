from pathlib import Path

import joblib
import numpy as np
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel, Field

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_DIR = BASE_DIR / "artifacts"
STATIC_DIR = Path(__file__).resolve().parent / "static"

FEATURES = [
    "battery_health_percent",
    "state_of_health",
    "capacity_loss_percent",
    "aging_score",
    "cell_voltage_std",
    "charge_efficiency",
    "cycle_count",
    "odometer_km",
    "voltage_imbalance",
    "charging_quality_score",
    "thermal_runaway_risk",
    "thermal_health_score",
    "daily_distance",
    "internal_resistance",
    "charging_cycles_last_month",
]

model = joblib.load(MODEL_DIR / "battery_failure_model.joblib")
imputer = joblib.load(MODEL_DIR / "battery_imputer.joblib")
scaler = joblib.load(MODEL_DIR / "battery_scaler.joblib")

app = FastAPI(
    title="EV Battery Early Warning System",
    description="Neural-network API for estimating EV battery failure risk.",
    version="1.0.0",
)


class BatteryReading(BaseModel):
    battery_health_percent: float = Field(..., ge=0, le=100)
    state_of_health: float = Field(..., ge=0, le=100)
    capacity_loss_percent: float = Field(..., ge=0, le=100)
    aging_score: float = Field(..., ge=0)
    cell_voltage_std: float = Field(..., ge=0)
    charge_efficiency: float = Field(..., ge=0)
    cycle_count: float = Field(..., ge=0)
    odometer_km: float = Field(..., ge=0)
    voltage_imbalance: float = Field(..., ge=0)
    charging_quality_score: float = Field(..., ge=0)
    thermal_runaway_risk: float = Field(..., ge=0)
    thermal_health_score: float = Field(..., ge=0)
    daily_distance: float = Field(..., ge=0)
    internal_resistance: float = Field(..., ge=0)
    charging_cycles_last_month: float = Field(..., ge=0)


@app.get("/", response_class=HTMLResponse)
def home():
    return (STATIC_DIR / "index.html").read_text(encoding="utf-8")


@app.get("/health")
def health_check():
    return {"status": "healthy", "model": "EV battery failure neural network"}


@app.post("/predict")
def predict(reading: BatteryReading):
    values = [[getattr(reading, feature) for feature in FEATURES]]
    values = scaler.transform(imputer.transform(values))

    failure_probability = float(model.predict_proba(values)[0, 1])
    prediction = int(failure_probability >= 0.5)

    if failure_probability < 0.30:
        risk_level = "LOW RISK"
        recommendation = "The battery currently shows relatively low failure risk. Continue normal monitoring."
    elif failure_probability < 0.70:
        risk_level = "MODERATE RISK"
        recommendation = "The battery shows some warning signs. Consider closer monitoring and a routine inspection."
    else:
        risk_level = "HIGH RISK"
        recommendation = "The battery shows elevated failure risk. Professional inspection is recommended."

    return {
        "battery_failure": prediction,
        "failure_probability": round(failure_probability, 4),
        "risk_level": risk_level,
        "recommendation": recommendation,
    }
